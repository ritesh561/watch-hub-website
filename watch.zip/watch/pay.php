<?php
// Include database connection file
include('constants.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $pincode = $_POST['pincode'];
    $card_type = $_POST['card_type'];
    $card_number = $_POST['card_number'];
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];

    // Prepare and execute SQL statement to insert data into the database
    $sql = "INSERT INTO payments (name, address, email, pincode, card_type, card_number, expiry_date, cvv) 
            VALUES ('$name', '$address', '$email', '$pincode', '$card_type', '$card_number', '$expiry_date', '$cvv')";

    if ($conn->query($sql) === TRUE) {
        echo "Payment details saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close database connection
    $conn->close();
}
?>
